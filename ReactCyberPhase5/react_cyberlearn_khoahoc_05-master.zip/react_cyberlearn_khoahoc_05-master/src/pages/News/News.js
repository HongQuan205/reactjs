import React from 'react'

export default function News() {
    return (
        <div>
            news
        </div>
    )
}
