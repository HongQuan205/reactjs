export const SET_CHI_TIET_PHONG_VE = 'SET_CHI_TIET_PHONG_VE';

export const DAT_VE = 'DAT_VE';


export const DAT_VE_HOAN_TAT = 'DAT_VE_HOAN_TAT';



export const CHUYEN_TAB = 'CHUYEN_TAB';