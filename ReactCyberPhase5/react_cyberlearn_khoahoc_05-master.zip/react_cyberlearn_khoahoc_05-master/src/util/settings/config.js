//Định nghĩa các tham số cố định
// export const DOMAIN = 'https://localhost:5001'; 
export const DOMAIN = 'http://movieapi.cyberlearn.vn';
export const TOKEN = 'accessToken';
export const GROUPID = 'GP01';


export const USER_LOGIN = 'USER_LOGIN';